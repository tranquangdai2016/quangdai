<h1>chu nang san pham</h1>
<?php echo $msg; echo $idsp;