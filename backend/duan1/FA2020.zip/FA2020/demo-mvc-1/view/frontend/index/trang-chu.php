<h1>day la trang chu ok ! </h1>
<?php echo $msg;