<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1 style="background-color: red;">trang chu </h1>
    <h1 style="background-color: blue;">header</h1>
    
    <h2>page hien thi</h2>
    <?php require_once APP_PATH.'/view/'.$module.'/'.$view_name ?>
    <hr>
    <h1 style="background-color: pink;">footer</h1>
    
</body>
</html>