<h1>đăng nhập </h1>

<form action="" method="POS">
    tên <input type="text" name="username">
    <button> login</button>
</form>