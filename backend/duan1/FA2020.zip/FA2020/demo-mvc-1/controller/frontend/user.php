<?php 
switch($action){
    case 'login': 
        extract(DangNhap()); break;
        case 'lagout': 
            break;
     case 'cuong': echo "fdsfdsf";       
        default: break;

}
function DangNhap(){

    $msg="ham dang nhap";
    if(isset($_POST['username'])){

        $msg.='xin chào '.$_POST['username'];
    }
    return [
        'view_name'=> 'user/login.php',
        'msg'=>$msg
    ];
}